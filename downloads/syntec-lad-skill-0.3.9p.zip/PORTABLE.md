# Portable Use: Codex, WorkBuddy, and Other Agents

The skill is deliberately split into portable and platform-specific parts.

| Part | Portable? | Notes |
|---|---|---|
| `SKILL.md` | Yes | Standard Agent Skill entry point |
| `references/` | Yes | Plain Markdown, JSON, CSV |
| `scripts/run_syntec_lad.py` | Yes | Any agent that can run Python |
| `scripts/syntec_lad_mcp.py` | Yes | MCP stdio adapter |
| `LadDLL.SyntaxCheck` | Windows only | Requires 32-bit LadDLL.dll and .NET Framework |
| `MLCEdit.exe` review | Windows only | Human review step only |

## WorkBuddy

Install into the WorkBuddy skill and MCP locations:

```powershell
python .\scripts\install_workbuddy.py
```

Or double-click `scripts\install_workbuddy.bat`.

The installer:

1. copies this directory to `~/.workbuddy/skills/syntec-lad/`;
2. backs up an existing skill directory outside the skills scan directory;
3. merges a `syntec-lad` entry into `~/.workbuddy/mcp.json`;
4. backs up an existing `mcp.json`;
5. runs CLI and MCP self-checks before changing anything.

WorkBuddy 5.9.3 reads `~/.workbuddy/mcp.json` and treats an entry with a
`command` as a stdio server. After installation, fully exit WorkBuddy,
reopen it, open the MCP Servers page, and confirm `syntec-lad` is listed.
Approve/trust it if WorkBuddy prompts.

## Other MCP clients

Claude Desktop, Cursor, and other MCP clients can register the same stdio
server. See `mcp-config.example.json` and replace the path:

```json
{
  "mcpServers": {
    "syntec-lad": {
      "command": "python",
      "args": ["C:/path/to/syntec-lad/scripts/syntec_lad_mcp.py"]
    }
  }
}
```

The MCP tools are:

- `inspect_lad`（支持 `program` / `network` 过滤）
- `lookup_address`（C/S/R 地址、R 分区/权限/保持/位存取、`@` 公用变量到 R 的分段映射、`R@R` 间接寻址）
- `build_plan`
- `patch_lad`
- `validate_lad`
- `diff_lad`（段对齐 + 操作数级差异）
- `lint_lad`（重复线圈 / S 当线圈 / I/O 复用 / 越界 / 简体注释 / 可合并条件）
- `lint_plan`（生成前 DNF 合并审计 / 动作母线宽度 / 流程动作）
- `crosscheck_lad`（参数表、三语、报警位、IO 表四项核对；可用 `delivery` 自动定位，`snapshots` 对照 Confluence 快照）
- `resource_report`（已用/空闲地址盘点，只出候选不分配）
- `comment_coverage`（L1 接口点 / L2 程序头 / L3 长注释）
- `confluence_status`（云端校验级别与离线降级说明）
- `read_reference`
- `list_references`
- `explain_capabilities`

## Agent Skills directories

For an agent that reads the Agent Skills layout but does not use WorkBuddy,
copy this whole directory into its skill directory. Typical locations:

```text
~/.codebuddy/skills/syntec-lad/     (CodeBuddy)
~/.codex/skills/syntec-lad/         (Codex)
~/.workbuddy/skills/syntec-lad/     (WorkBuddy)
```

The same folder can be used from any checkout:

```powershell
python .\scripts\run_syntec_lad.py --version
python .\scripts\run_syntec_lad.py inspect .\source.lad
python .\scripts\run_syntec_lad.py lookup C6
python .\scripts\run_syntec_lad.py lookup R2050
python .\scripts\run_syntec_lad.py lookup @108001
```

## Platform boundary

Knowledge lookup, parsing, plan generation, patch preparation, and diffing work
without LadEditor. Final native validation still requires Windows, a 32-bit
`LadDLL.dll`, and .NET Framework 4.x (`csc.exe`). Standard C-drive paths are
checked first; missing installations are located with a bounded search on
other local fixed drives. Do not describe a file as fully validated if only
the Python readback ran.

The MCP server never clicks the editor and never uploads to a CNC. `open` is
not exposed as an MCP tool; human review remains an explicit CLI action.
